/**
 * 
 * @Title: AppStater
 * @Description:
 * @author:wyw
 * @date: 2022年12月25日上午11:53:21
 *
 */
package nuc.ss.frame;

public class AppStater {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LoginWindow("车票系统登录界面");
	}

}

/**
 * 
 * @Title: BoxSeatQuantity
 * @Description:车厢座位数量
 * @author:wyw
 * @date: 2022年12月25日上午11:41:13
 *
 */
package nuc.ss.entity;

public class BoxSeatQuantity {
    private String boxquantity;
	private String seatquantity;

	    public String getBoxquantity() {
	        return boxquantity;
	    }
	    public void setBoxquantity(String boxquantity) {
	        this.boxquantity = boxquantity;
	    }
	    public String getSeatquantity() {
	        return seatquantity;
	    }
	    public void setSeatquantity(String seatquantity) {
	        this.seatquantity = seatquantity;
	    }
}
